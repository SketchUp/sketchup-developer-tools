#!/usr/bin/ruby -w
#
# Stored history cache. This file is updated in response to explicit saves.
# Updating this file for use as a "common snippets" file is possible but it
# may be overwritten if you execute a save command from within the console.

Developer::Console.setHistory(
)
