#!/usr/bin/ruby
#
#Test file to see if I can load a certain class
# this file define the class LoadTest1

class LoadTest1
  def initialize(p1, p2)
    @a = "LoadTest1"
    @b = p1
    @c = p2
  end
end

