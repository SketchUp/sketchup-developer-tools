#!/usr/bin/ruby
#
#Test file to see if I can load a certain class
# this file define the class LoadTest2

class LoadTest2
  def initialize(p1, p2)
    @a = "LoadTest2"
    @b = p1
    @c = p2
  end
end
